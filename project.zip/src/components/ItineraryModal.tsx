import React, { useState } from 'react';
import { X, Image, Download } from 'lucide-react';
import { Trip } from '../types';
import { exportItineraryPosterPNG } from '../utils/canvasExport';
import { ItineraryEditor } from './ItineraryEditor';

interface ItineraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  trip: Trip | null;
  onUpdateTripItinerary: (newItinerary: string) => void;
  onShowToast: (msg: string) => void;
}

export const ItineraryModal: React.FC<ItineraryModalProps> = ({
  isOpen,
  onClose,
  trip,
  onUpdateTripItinerary,
  onShowToast,
}) => {
  if (!isOpen || !trip) return null;

  const [itineraryText, setItineraryText] = useState(trip.itinerary || '');
  const [isExporting, setIsExporting] = useState<string | null>(null);

  const handleSave = () => {
    onUpdateTripItinerary(itineraryText);
    onShowToast('Itinerary berhasil diperbarui');
    onClose();
  };

  const handleExportPNG = async (ratio: '4:5' | '9:16') => {
    setIsExporting(ratio);
    onShowToast(`Membuat pamflet itinerary (${ratio})...`);
    try {
      // Create a shallow copy with current updated itinerary text
      const tripCopy: Trip = { ...trip, itinerary: itineraryText };
      await exportItineraryPosterPNG(tripCopy, ratio);
      onShowToast(`Poster Itinerary (${ratio}) berhasil diunduh!`);
    } catch (err) {
      console.error(err);
      onShowToast('Gagal membuat poster itinerary');
    } finally {
      setIsExporting(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-4 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#18261E] border border-[#2F4435] text-[#E8E6DF] w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden my-4 sm:my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-[#121D17] px-5 sm:px-6 py-4 border-b border-[#2F4435] flex items-center justify-between">
          <div>
            <span className="text-[10px] sm:text-xs font-bold tracking-widest text-[#E2A83B] uppercase font-['Space_Grotesk']">
              Rundown & Arsip Media Sosial
            </span>
            <h2 className="text-lg sm:text-xl font-bold font-['Space_Grotesk'] text-white">
              🗓️ Itinerary {trip.nama_gunung} ({trip.jalur})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-md hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-4">
          <ItineraryEditor
            value={itineraryText}
            onChange={setItineraryText}
            namaGunung={trip.nama_gunung}
            jalur={trip.jalur}
            tanggalMulai={trip.tanggal_mulai}
            tanggalSelesai={trip.tanggal_selesai}
            onShowToast={onShowToast}
          />

          {/* Export Action Bar specifically for Itinerary */}
          <div className="bg-[#131F18] border border-[#25392B] rounded-lg p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h4 className="font-bold text-white text-xs sm:text-sm flex items-center gap-1.5 font-['Space_Grotesk']">
                <Image className="w-4 h-4 text-[#E2A83B]" />
                Export Poster Pamflet Itinerary
              </h4>
              <p className="text-[11px] text-gray-400 mt-0.5">
                Pilih format rasio postingan untuk Instagram Feed atau Instagram Story
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => handleExportPNG('4:5')}
                disabled={isExporting !== null}
                className="flex-1 sm:flex-none px-3.5 py-2 rounded text-xs font-bold bg-[#23382A] hover:bg-[#2D4736] text-[#E2A83B] border border-[#3A5A44] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PNG (4:5 Feed)</span>
              </button>

              <button
                onClick={() => handleExportPNG('9:16')}
                disabled={isExporting !== null}
                className="flex-1 sm:flex-none px-3.5 py-2 rounded text-xs font-bold bg-[#E2A83B] hover:bg-[#EEBB55] text-[#16241B] transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PNG (9:16 Story)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#121D17] px-5 sm:px-6 py-3 border-t border-[#2F4435] flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs sm:text-sm font-semibold text-gray-300 hover:text-white bg-[#223528] hover:bg-[#2B4233] rounded transition-colors cursor-pointer"
          >
            Tutup
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-1.5 text-xs sm:text-sm font-bold text-[#16241B] bg-[#E2A83B] hover:bg-[#EEBB55] rounded transition-all cursor-pointer shadow"
          >
            Simpan Perubahan
          </button>
        </div>
      </div>
    </div>
  );
};
