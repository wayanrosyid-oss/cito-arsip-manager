import React from 'react';
import { Calendar, Clock, Users, MapPin, Edit3, Trash2, FileText, ChevronRight } from 'lucide-react';
import { Trip } from '../types';
import { formatDateRange } from '../utils/formatters';

interface TripCardProps {
  trip: Trip;
  onSelect: (trip: Trip) => void;
  onEdit: (trip: Trip) => void;
  onDelete: (id: string) => void;
  onOpenItinerary: (trip: Trip) => void;
  isSelected?: boolean;
}

export const TripCard: React.FC<TripCardProps> = ({
  trip,
  onSelect,
  onEdit,
  onDelete,
  onOpenItinerary,
  isSelected,
}) => {
  const isBuka = trip.status === 'Buka';
  const dateRange = formatDateRange(trip.tanggal_mulai, trip.tanggal_selesai) || 'Jadwal Terbuka';

  return (
    <div
      className={`group relative rounded-xl border p-4 sm:p-5 transition-all cursor-pointer ${
        isSelected
          ? 'bg-[#1C2C21] border-[#E2A83B] shadow-lg ring-1 ring-[#E2A83B]/40'
          : 'bg-[#15231A] border-[#293E30] hover:border-[#3C5B46] hover:bg-[#192A20]'
      }`}
      onClick={() => onSelect(trip)}
    >
      <div className="flex items-start justify-between gap-3">
        {/* Left Info */}
        <div className="space-y-1.5 flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Status Pill: Buka / Tutup */}
            <span
              className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wide ${
                isBuka
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${isBuka ? 'bg-emerald-400' : 'bg-rose-400'}`} />
              {trip.status}
            </span>

            {/* Jalur Tag */}
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#E2A83B] bg-[#223528] px-2 py-0.5 rounded border border-[#314E3A]">
              <MapPin className="w-3 h-3" />
              {trip.jalur}
            </span>
          </div>

          {/* Mountain Name + MDPL */}
          <h3 className="text-base sm:text-lg font-bold font-['Space_Grotesk'] text-white truncate group-hover:text-[#F3FAF5] transition-colors">
            {trip.nama_gunung} {trip.ketinggian_mdpl && <span className="text-gray-300 font-normal text-sm sm:text-base">({trip.ketinggian_mdpl})</span>}
          </h3>

          {/* Date & Duration */}
          <div className="flex items-center gap-3 sm:gap-4 text-xs text-gray-300 flex-wrap pt-1">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#E2A83B]" />
              <span>{dateRange}</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#FCD34D] font-semibold">
              <Clock className="w-3.5 h-3.5" />
              <span>{trip.durasi}</span>
            </div>
            <div className="flex items-center gap-1.5 text-gray-400">
              <Users className="w-3.5 h-3.5" />
              <span>{trip.min_peserta || '-'}–{trip.max_peserta || '-'} pax</span>
            </div>
          </div>
        </div>

        {/* Right Arrow */}
        <div className="flex items-center gap-1 shrink-0">
          <ChevronRight className={`w-5 h-5 transition-transform ${isSelected ? 'text-[#E2A83B] translate-x-1' : 'text-gray-500 group-hover:text-gray-300'}`} />
        </div>
      </div>

      {/* Quick Action Footer */}
      <div className="mt-3.5 pt-3 border-t border-[#233528] flex items-center justify-between gap-2 text-xs" onClick={(e) => e.stopPropagation()}>
        <button
          onClick={() => onOpenItinerary(trip)}
          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#1F3325] hover:bg-[#284230] text-[#E2A83B] border border-[#32523A] transition-colors font-semibold cursor-pointer"
          title="Buka & edit itinerary rundown"
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Itinerary</span>
        </button>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onEdit(trip)}
            className="p-1.5 text-gray-400 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
            title="Edit trip"
          >
            <Edit3 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              if (confirm(`Yakin ingin menghapus trip ${trip.nama_gunung}?`)) {
                onDelete(trip.id);
              }
            }}
            className="p-1.5 text-gray-400 hover:text-rose-400 hover:bg-rose-900/20 rounded transition-colors cursor-pointer"
            title="Hapus trip"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
