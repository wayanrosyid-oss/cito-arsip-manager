import React from 'react';
import { Plus, Archive, Github, DownloadCloud } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { downloadProjectZip } from '../utils/projectZip';

interface NavbarProps {
  onOpenAddModal: () => void;
  onOpenGithubGuide: () => void;
  tripCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAddModal,
  onOpenGithubGuide,
  tripCount,
}) => {
  return (
    <header className="bg-[#16241B] border-b border-[#293E30] text-[#F1EEE3] sticky top-0 z-40 shadow-md">
      <div className="max-w-6xl mx-auto px-4 py-3 sm:py-4 flex items-center justify-between gap-3 flex-wrap">
        {/* Left: Brand with uploaded Cito Adventure logo */}
        <div className="flex items-center gap-3">
          <img
            src="/logo.png"
            alt="Logo Cito Adventure Madiun"
            className="w-11 h-11 sm:w-12 sm:h-12 object-contain rounded-md drop-shadow-md bg-[#101A13] p-0.5 border border-[#E2A83B]/40"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] sm:text-xs font-bold tracking-widest text-[#E2A83B] uppercase font-['Space_Grotesk']">
                Cito Adventure Madiun
              </span>
              <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-[#223B2A] text-[#86EFAC] border border-[#3B6647]">
                PWA Offline
              </span>
            </div>
            <h1 className="text-lg sm:text-xl font-bold font-['Space_Grotesk'] tracking-tight text-white leading-tight">
              Arsip Trip & Generator Konten
            </h1>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
          <PWAInstallButton />

          <button
            id="download-zip-btn"
            onClick={downloadProjectZip}
            className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold bg-[#1D2F23] hover:bg-[#253D2D] text-[#C9D6C7] border border-[#2E4A35] transition-colors cursor-pointer"
            title="Download seluruh source code aplikasi dalam format .ZIP"
          >
            <DownloadCloud className="w-3.5 h-3.5 text-[#E2A83B]" />
            <span>Unduh File ZIP</span>
          </button>

          <button
            id="github-guide-btn"
            onClick={onOpenGithubGuide}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold bg-[#1D2F23] hover:bg-[#253D2D] text-[#C9D6C7] border border-[#2E4A35] transition-colors cursor-pointer"
            title="Panduan push ke Repository GitHub"
          >
            <Github className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Repo GitHub</span>
          </button>

          <button
            id="add-trip-btn"
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded text-xs sm:text-sm font-bold bg-[#E2A83B] hover:bg-[#EEBB55] text-[#16241B] transition-all shadow cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Trip</span>
          </button>
        </div>
      </div>
    </header>
  );
};
