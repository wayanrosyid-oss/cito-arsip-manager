export type TripStatus = 'Buka' | 'Tutup';

export interface MeetingPoint {
  lokasi: string;
  harga: string;
}

export interface Trip {
  id: string;
  nama_gunung: string;
  ketinggian_mdpl: string;
  jalur: string;
  status: TripStatus;
  tanggal_mulai: string;
  tanggal_selesai: string;
  durasi: string;
  min_peserta: string;
  max_peserta: string;
  harga_mepo: MeetingPoint[];
  include: string[];
  exclude: string[];
  extra_porter?: string;
  sk_berlaku: string[];
  catatan_penting?: string;
  itinerary: string;
  kontak_wa: string;
  kontak_ig: string;
  created_at: number;
  updated_at: number;
}

export interface MountainItem {
  name: string;
  height: string; // e.g. "3.153 MDPL"
  province: string;
  trails: string[];
}
