import JSZip from 'jszip';

export async function downloadProjectZip(): Promise<void> {
  const zip = new JSZip();

  // Root files & configs
  zip.file(
    'package.json',
    JSON.stringify(
      {
        name: 'cito-adventure-trip-archive',
        private: true,
        version: '1.0.0',
        type: 'module',
        scripts: {
          dev: 'vite --port=3000 --host=0.0.0.0',
          build: 'vite build',
          preview: 'vite preview'
        },
        dependencies: {
          jspdf: '^4.2.1',
          jszip: '^3.10.1',
          'lucide-react': '^0.546.0',
          motion: '^12.23.24',
          react: '^19.0.1',
          'react-dom': '^19.0.1'
        },
        devDependencies: {
          '@tailwindcss/vite': '^4.1.14',
          '@types/node': '^22.14.0',
          '@vitejs/plugin-react': '^5.0.4',
          tailwindcss: '^4.1.14',
          typescript: '~5.8.2',
          vite: '^6.2.3',
          'vite-plugin-pwa': '^0.21.1'
        }
      },
      null,
      2
    )
  );

  zip.file(
    'README.md',
    `# Cito Adventure - Arsip Trip Gunung (PWA)

Aplikasi Progressive Web App (PWA) lengkap untuk manajemen arsip open trip dan generator materi promosi media sosial Cito Adventure Madiun:
- 🏔️ Database nama gunung populer Indonesia lengkap dengan ketinggian (MDPL)
- 📌 Rekomendasi jalur otomatis yang bisa disesuaikan
- 📅 Rentang tanggal dan kalkulasi durasi otomatis (mis. 2 Hari 1 Malam)
- 📍 Status trip sederhana: Buka / Tutup
- 👥 Kuota peserta dan notifikasi penyesuaian harga
- 🗓️ Rundown / Itinerary lengkap (termasuk H-1 malam keberangkatan)
- 📋 Generator caption Instagram ringkas dengan hashtag dinamis otomatis
- 🖼️ Export Pamflet Trip & Itinerary dalam rasio 4:5 (Feed) dan 9:16 (Story)
- 📄 Export PDF & TXT
- 📱 PWA Installable (Bisa diinstall di Android, iOS, dan Desktop tanpa koneksi internet)

## Cara Menjalankan

\`\`\`bash
npm install
npm run dev
\`\`\`

Buka di browser pada \`http://localhost:3000\`
`
  );

  zip.file(
    '.gitignore',
    `node_modules/
dist/
.DS_Store
*.local
`
  );

  // Generate the zip and trigger download
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `cito-adventure-pwa-source-${new Date().toISOString().split('T')[0]}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
