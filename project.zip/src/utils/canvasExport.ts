import { Trip } from '../types';
import { formatDateRange } from './formatters';

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number
): number {
  const words = text.split(' ');
  let line = '';
  let currentY = y;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;
    if (testWidth > maxWidth && n > 0) {
      ctx.fillText(line.trim(), x, currentY);
      line = words[n] + ' ';
      currentY += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line.trim(), x, currentY);
  return currentY + lineHeight;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
  fill = true,
  stroke = false
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

function triggerDownload(canvas: HTMLCanvasElement, filename: string) {
  canvas.toBlob((blob) => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }, 'image/png');
}

export async function exportTripPamphletPNG(trip: Trip, ratio: '4:5' | '9:16'): Promise<void> {
  const width = 1080;
  const height = ratio === '4:5' ? 1350 : 1920;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Background gradient: Dark outdoor forest
  const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
  bgGrad.addColorStop(0, '#101B14');
  bgGrad.addColorStop(0.5, '#16241B');
  bgGrad.addColorStop(1, '#0D1510');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Decorative subtle grid / topo lines
  ctx.strokeStyle = 'rgba(226, 168, 59, 0.05)';
  ctx.lineWidth = 1;
  for (let y = 0; y < height; y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  // Top Accent Banner
  ctx.fillStyle = '#E2A83B';
  ctx.fillRect(0, 0, width, 8);

  const padX = 64;
  let curY = 54;

  // Header Brand Tag
  ctx.fillStyle = '#E2A83B';
  ctx.font = '700 20px "Space Grotesk", sans-serif';
  ctx.letterSpacing = '2px';
  ctx.fillText('CITO ADVENTURE MADIUN · OPEN TRIP RESMI', padX, curY);
  curY += 46;

  // Title: Mountain Name & MDPL
  const mtnName = (trip.nama_gunung || 'GUNUNG').toUpperCase();
  const heightStr = trip.ketinggian_mdpl ? ` ${trip.ketinggian_mdpl.toUpperCase()}` : '';
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '800 52px "Space Grotesk", sans-serif';
  curY = wrapText(ctx, `${mtnName}${heightStr}`, padX, curY, width - padX * 2, 60);

  // Subtitle / Jalur + Status Pill
  const jalurText = (trip.jalur || 'VIA BASECAMP').toUpperCase();
  ctx.fillStyle = '#E2A83B';
  ctx.font = '700 28px "Space Grotesk", sans-serif';
  ctx.fillText(`📌 ${jalurText}`, padX, curY + 4);

  // Status Badge
  const isBuka = trip.status === 'Buka';
  const statusBadgeX = width - padX - 160;
  ctx.fillStyle = isBuka ? '#22C55E' : '#EF4444';
  roundRect(ctx, statusBadgeX, curY - 26, 160, 42, 8, true, false);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '700 20px "Space Grotesk", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(isBuka ? 'STATUS: BUKA' : 'STATUS: TUTUP', statusBadgeX + 80, curY + 2);
  ctx.textAlign = 'left';
  curY += 40;

  // Divider line
  ctx.strokeStyle = 'rgba(201, 194, 172, 0.25)';
  ctx.beginPath();
  ctx.moveTo(padX, curY);
  ctx.lineTo(width - padX, curY);
  ctx.stroke();
  curY += 24;

  // Info Cards Row: Tanggal, Durasi, Peserta
  const dateRange = formatDateRange(trip.tanggal_mulai, trip.tanggal_selesai) || 'Jadwal Terbuka';
  const durasi = trip.durasi || '2 Hari 1 Malam';
  const kuota = trip.min_peserta && trip.max_peserta
    ? `${trip.min_peserta} – ${trip.max_peserta} Pax`
    : (trip.min_peserta ? `Min ${trip.min_peserta} Pax` : (trip.max_peserta ? `Maks ${trip.max_peserta} Pax` : 'Sesuai Kuota'));

  const cardW = (width - padX * 2 - 28) / 3;
  const cardH = 92;

  // Card 1: Tanggal
  ctx.fillStyle = '#1D2E23';
  roundRect(ctx, padX, curY, cardW, cardH, 10, true, false);
  ctx.fillStyle = '#A7B7A9';
  ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('📅 TANGGAL TRIP', padX + 16, curY + 28);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '700 18px "Space Grotesk", sans-serif';
  ctx.fillText(dateRange, padX + 16, curY + 62);

  // Card 2: Durasi
  ctx.fillStyle = '#1D2E23';
  roundRect(ctx, padX + cardW + 14, curY, cardW, cardH, 10, true, false);
  ctx.fillStyle = '#A7B7A9';
  ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('🕒 DURASI PENDAKIAN', padX + cardW + 30, curY + 28);
  ctx.fillStyle = '#E2A83B';
  ctx.font = '700 20px "Space Grotesk", sans-serif';
  ctx.fillText(durasi, padX + cardW + 30, curY + 62);

  // Card 3: Kuota Peserta
  ctx.fillStyle = '#1D2E23';
  roundRect(ctx, padX + (cardW + 14) * 2, curY, cardW, cardH, 10, true, false);
  ctx.fillStyle = '#A7B7A9';
  ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('👥 KUOTA PESERTA', padX + (cardW + 14) * 2 + 16, curY + 28);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '700 20px "Space Grotesk", sans-serif';
  ctx.fillText(kuota, padX + (cardW + 14) * 2 + 16, curY + 62);

  curY += cardH + 12;

  // Peserta note
  ctx.fillStyle = '#FCD34D';
  ctx.font = 'italic 14px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('*(Jika peserta kurang dari kuota minimal, akan ada penyesuaian harga)', padX, curY + 4);
  curY += 28;

  // Meeting Points Box
  ctx.fillStyle = '#18261E';
  ctx.strokeStyle = '#344C3A';
  ctx.lineWidth = 1;
  const mepoBoxH = Math.min(180, 50 + (trip.harga_mepo?.length || 1) * 32);
  roundRect(ctx, padX, curY, width - padX * 2, mepoBoxH, 10, true, true);

  ctx.fillStyle = '#E2A83B';
  ctx.font = '700 18px "Space Grotesk", sans-serif';
  ctx.fillText('💰 TARIF PER MEETING POINT (MEPO):', padX + 20, curY + 30);

  let mepoY = curY + 62;
  const mepoItems = trip.harga_mepo && trip.harga_mepo.length > 0 ? trip.harga_mepo : [{ lokasi: 'Basecamp', harga: 'Hubungi Admin' }];
  for (const m of mepoItems.slice(0, 4)) {
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '600 17px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`• ${m.lokasi || 'Meeting Point'}`, padX + 24, mepoY);

    ctx.fillStyle = '#FBBF24';
    ctx.font = '700 18px "Space Grotesk", sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(m.harga || '-', width - padX - 24, mepoY);
    ctx.textAlign = 'left';
    mepoY += 30;
  }

  curY += mepoBoxH + 22;

  // Two Column: Include & Exclude
  const colW = (width - padX * 2 - 20) / 2;
  const colH = ratio === '4:5' ? 380 : 540;

  // Include Box
  ctx.fillStyle = '#142018';
  ctx.strokeStyle = 'rgba(74, 222, 128, 0.3)';
  roundRect(ctx, padX, curY, colW, colH, 10, true, true);

  ctx.fillStyle = '#4ADE80';
  ctx.font = '700 18px "Space Grotesk", sans-serif';
  ctx.fillText('✅ FASILITAS INCLUDE:', padX + 20, curY + 32);

  let incY = curY + 66;
  const incItems = trip.include && trip.include.length > 0 ? trip.include : ['Transportasi PP', 'Simaksi Pendakian', 'Tenda & Matras', 'Makan Selama Pendakian', 'Guide & Porter Tim'];
  const maxInc = ratio === '4:5' ? 8 : 12;
  for (const item of incItems.slice(0, maxInc)) {
    ctx.fillStyle = '#E5E7EB';
    ctx.font = '500 15px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`✓  ${item}`, padX + 20, incY);
    incY += 28;
  }

  // Exclude Box
  ctx.fillStyle = '#142018';
  ctx.strokeStyle = 'rgba(248, 113, 113, 0.3)';
  roundRect(ctx, padX + colW + 20, curY, colW, colH, 10, true, true);

  ctx.fillStyle = '#F87171';
  ctx.font = '700 18px "Space Grotesk", sans-serif';
  ctx.fillText('❌ EXCLUDE (TIDAK TERMASUK):', padX + colW + 40, curY + 32);

  let excY = curY + 66;
  const excItems = trip.exclude && trip.exclude.length > 0 ? trip.exclude : ['Perlengkapan Pribadi', 'Obat-obatan Pribadi', 'Camilan / Logistik Pribadi', 'Tips Sukarela Crew'];
  const maxExc = ratio === '4:5' ? 6 : 9;
  for (const item of excItems.slice(0, maxExc)) {
    ctx.fillStyle = '#E5E7EB';
    ctx.font = '500 15px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`✕  ${item}`, padX + colW + 40, excY);
    excY += 28;
  }

  if (trip.extra_porter) {
    ctx.fillStyle = '#FCD34D';
    ctx.font = '600 14px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`🎒 Extra Porter: ${trip.extra_porter}`, padX + colW + 40, excY + 8);
  }

  curY += colH + 20;

  // Bottom Notice & S&K if space allows in 9:16
  if (ratio === '9:16') {
    const skBoxH = 180;
    ctx.fillStyle = '#19261E';
    roundRect(ctx, padX, curY, width - padX * 2, skBoxH, 10, true, false);
    ctx.fillStyle = '#E2A83B';
    ctx.font = '700 16px "Space Grotesk", sans-serif';
    ctx.fillText('📋 S&K SINGKAT & CATATAN PENTING:', padX + 20, curY + 28);

    let skY = curY + 56;
    const skItems = trip.sk_berlaku && trip.sk_berlaku.length > 0
      ? trip.sk_berlaku
      : ['Terbuka untuk umum (solo hiker dipersilakan join)', 'DP minimal 50% untuk pengamanan kuota', 'Pelunasan maksimal H-3 sebelum keberangkatan'];
    for (const sk of skItems.slice(0, 4)) {
      ctx.fillStyle = '#D1D5DB';
      ctx.font = '500 14px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(`• ${sk}`, padX + 20, skY);
      skY += 25;
    }
  }

  // Footer bar: Contact & Booking
  const footerH = 88;
  const footerY = height - footerH;
  ctx.fillStyle = '#0B130E';
  ctx.fillRect(0, footerY, width, footerH);

  ctx.strokeStyle = '#E2A83B';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, footerY);
  ctx.lineTo(width, footerY);
  ctx.stroke();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '700 20px "Space Grotesk", sans-serif';
  ctx.fillText('INFORMASI & BOOKING:', padX, footerY + 52);

  ctx.fillStyle = '#4ADE80';
  ctx.font = '700 21px "Space Grotesk", sans-serif';
  ctx.fillText(`WA: ${trip.kontak_wa || '+6282230444428'}`, padX + 240, footerY + 52);

  ctx.fillStyle = '#E2A83B';
  ctx.textAlign = 'right';
  ctx.font = '700 18px "Space Grotesk", sans-serif';
  ctx.fillText(`IG: ${trip.kontak_ig || '@citoadventure'}`, width - padX, footerY + 52);
  ctx.textAlign = 'left';

  const filename = `pamflet-${trip.nama_gunung.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${trip.jalur.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${ratio.replace(':', 'x')}.png`;
  triggerDownload(canvas, filename);
}

export async function exportItineraryPosterPNG(trip: Trip, ratio: '4:5' | '9:16'): Promise<void> {
  const width = 1080;
  const height = ratio === '4:5' ? 1350 : 1920;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Background gradient: Deep mountain night / dawn
  const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
  bgGrad.addColorStop(0, '#0F1A13');
  bgGrad.addColorStop(0.4, '#15241B');
  bgGrad.addColorStop(1, '#0C140F');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Top Accent Banner
  ctx.fillStyle = '#E2A83B';
  ctx.fillRect(0, 0, width, 8);

  const padX = 64;
  let curY = 56;

  // Header Brand Tag
  ctx.fillStyle = '#E2A83B';
  ctx.font = '700 20px "Space Grotesk", sans-serif';
  ctx.letterSpacing = '2px';
  ctx.fillText('CITO ADVENTURE MADIUN · OFFICIAL RUNDOWN', padX, curY);
  curY += 46;

  // Main Header
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '800 46px "Space Grotesk", sans-serif';
  ctx.fillText('ITINERARY & RUNDOWN PENDAKIAN', padX, curY);
  curY += 44;

  const mtnName = (trip.nama_gunung || 'GUNUNG').toUpperCase();
  const heightStr = trip.ketinggian_mdpl ? ` ${trip.ketinggian_mdpl.toUpperCase()}` : '';
  const jalurText = (trip.jalur || 'VIA BASECAMP').toUpperCase();

  ctx.fillStyle = '#E2A83B';
  ctx.font = '700 28px "Space Grotesk", sans-serif';
  ctx.fillText(`🏔 ${mtnName}${heightStr} · 📌 ${jalurText}`, padX, curY);
  curY += 32;

  const dateRange = formatDateRange(trip.tanggal_mulai, trip.tanggal_selesai) || 'Jadwal Terbuka';
  const durasi = trip.durasi || '2 Hari 1 Malam';
  ctx.fillStyle = '#A7B7A9';
  ctx.font = '600 18px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(`📅 ${dateRange}   |   🕒 ${durasi}`, padX, curY);
  curY += 28;

  // Divider
  ctx.strokeStyle = 'rgba(201, 194, 172, 0.25)';
  ctx.beginPath();
  ctx.moveTo(padX, curY);
  ctx.lineTo(width - padX, curY);
  ctx.stroke();
  curY += 30;

  // Parse Itinerary Lines
  const rawItinerary = trip.itinerary || '';
  const lines = rawItinerary.split('\n').map(l => l.trim()).filter(Boolean);

  const contentH = height - curY - 120;
  ctx.fillStyle = '#152119';
  ctx.strokeStyle = '#2F4535';
  roundRect(ctx, padX, curY, width - padX * 2, contentH, 12, true, true);

  let itemY = curY + 36;
  const maxItemY = curY + contentH - 36;

  for (const line of lines) {
    if (itemY > maxItemY) break;

    // Check if line is a Day header (e.g. "Hari 0", "Hari 1", "Hari 2")
    const isDayHeader = line.toLowerCase().startsWith('hari ') || line.startsWith('🗓️');

    if (isDayHeader) {
      itemY += 10;
      ctx.fillStyle = '#E2A83B';
      roundRect(ctx, padX + 24, itemY - 22, width - padX * 2 - 48, 38, 6, true, false);
      ctx.fillStyle = '#16241B';
      ctx.font = '800 18px "Space Grotesk", sans-serif';
      ctx.fillText(line.replace(/^[•\-\*\s]+/, ''), padX + 38, itemY + 4);
      itemY += 38;
    } else {
      // Timeline item
      ctx.fillStyle = '#34D399';
      ctx.font = '700 16px "Space Grotesk", sans-serif';

      // If line has time pattern like "07.00 - 08.00 : Activity"
      const match = line.match(/^([•\-\*]?\s*)?(\d{2}[.:]\d{2}(?:\s*-\s*(?:\d{2}[.:]\d{2}|selesai))?)\s*[:\-]?\s*(.*)$/i);
      if (match) {
        const timePart = match[2];
        const descPart = match[3];

        ctx.fillStyle = '#FCD34D';
        ctx.font = '700 16px "Space Grotesk", sans-serif';
        ctx.fillText(timePart, padX + 38, itemY);

        ctx.fillStyle = '#F3F4F6';
        ctx.font = '500 16px "Plus Jakarta Sans", sans-serif';
        wrapText(ctx, descPart, padX + 190, itemY, width - padX * 2 - 220, 24);
        itemY += 28;
      } else {
        ctx.fillStyle = '#E5E7EB';
        ctx.font = '500 16px "Plus Jakarta Sans", sans-serif';
        itemY = wrapText(ctx, line, padX + 38, itemY, width - padX * 2 - 76, 24) + 4;
      }
    }
  }

  // Footer bar: Contact & Booking
  const footerH = 88;
  const footerY = height - footerH;
  ctx.fillStyle = '#0B130E';
  ctx.fillRect(0, footerY, width, footerH);

  ctx.strokeStyle = '#E2A83B';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, footerY);
  ctx.lineTo(width, footerY);
  ctx.stroke();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '700 18px "Space Grotesk", sans-serif';
  ctx.fillText('Catatan: Jadwal fleksibel menyesuaikan cuaca & fisik di lapangan.', padX, footerY + 34);

  ctx.fillStyle = '#E2A83B';
  ctx.font = '700 18px "Space Grotesk", sans-serif';
  ctx.fillText(`Booking: WA ${trip.kontak_wa || '+6282230444428'} · IG ${trip.kontak_ig || '@citoadventure'}`, padX, footerY + 62);

  const filename = `itinerary-${trip.nama_gunung.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${trip.jalur.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${ratio.replace(':', 'x')}.png`;
  triggerDownload(canvas, filename);
}
