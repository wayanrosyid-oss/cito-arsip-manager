/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { TripCard } from './components/TripCard';
import { TripDetail } from './components/TripDetail';
import { TripModal } from './components/TripModal';
import { ItineraryModal } from './components/ItineraryModal';
import { GitHubGuideModal } from './components/GitHubGuideModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { Toast } from './components/Toast';
import { Trip, TripStatus } from './types';
import { getStoredTrips, saveStoredTrips } from './utils/storage';
import { Search, Plus, Filter, Mountain, ArrowLeft } from 'lucide-react';

export default function App() {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [selectedTripId, setSelectedTripId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('Semua');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [isTripModalOpen, setIsTripModalOpen] = useState(false);
  const [tripToEdit, setTripToEdit] = useState<Trip | null>(null);
  const [isItineraryModalOpen, setIsItineraryModalOpen] = useState(false);
  const [itineraryTrip, setItineraryTrip] = useState<Trip | null>(null);
  const [isGithubGuideOpen, setIsGithubGuideOpen] = useState(false);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Mobile view toggle ('list' | 'detail')
  const [mobileTab, setMobileTab] = useState<'list' | 'detail'>('list');

  useEffect(() => {
    const loaded = getStoredTrips();
    setTrips(loaded);
    if (loaded.length > 0) {
      setSelectedTripId(loaded[0].id);
    }
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2800);
  };

  const handleSaveTrip = (savedTrip: Trip) => {
    const exists = trips.some((t) => t.id === savedTrip.id);
    let updated: Trip[];
    if (exists) {
      updated = trips.map((t) => (t.id === savedTrip.id ? savedTrip : t));
      showToast(`Trip ${savedTrip.nama_gunung} berhasil diperbarui`);
    } else {
      updated = [savedTrip, ...trips];
      showToast(`Trip ${savedTrip.nama_gunung} berhasil ditambahkan`);
    }
    setTrips(updated);
    saveStoredTrips(updated);
    setSelectedTripId(savedTrip.id);
    setMobileTab('detail');
  };

  const handleDeleteTrip = (id: string) => {
    const updated = trips.filter((t) => t.id !== id);
    setTrips(updated);
    saveStoredTrips(updated);
    showToast('Trip berhasil dihapus');
    if (selectedTripId === id) {
      setSelectedTripId(updated[0]?.id || null);
      if (updated.length === 0) {
        setMobileTab('list');
      }
    }
  };

  const handleOpenAddModal = () => {
    setTripToEdit(null);
    setIsTripModalOpen(true);
  };

  const handleOpenEditModal = (trip: Trip) => {
    setTripToEdit(trip);
    setIsTripModalOpen(true);
  };

  const handleOpenItineraryModal = (trip: Trip) => {
    setItineraryTrip(trip);
    setIsItineraryModalOpen(true);
  };

  const handleUpdateTripItinerary = (newItinerary: string) => {
    if (!itineraryTrip) return;
    const updatedTrip = { ...itineraryTrip, itinerary: newItinerary, updated_at: Date.now() };
    handleSaveTrip(updatedTrip);
    setItineraryTrip(updatedTrip);
  };

  // Filter & Search
  const filteredTrips = trips.filter((t) => {
    const matchesFilter =
      filterStatus === 'Semua' ? true : t.status === filterStatus;
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      query === '' ||
      t.nama_gunung.toLowerCase().includes(query) ||
      t.jalur.toLowerCase().includes(query) ||
      (t.ketinggian_mdpl && t.ketinggian_mdpl.toLowerCase().includes(query));
    return matchesFilter && matchesSearch;
  });

  const activeTrip = trips.find((t) => t.id === selectedTripId) || filteredTrips[0] || null;

  return (
    <div className="min-h-screen bg-[#0E1711] text-[#E8E6DF] flex flex-col font-['Plus_Jakarta_Sans'] selection:bg-[#E2A83B] selection:text-[#16241B]">
      {/* Top App Navbar */}
      <Navbar
        onOpenAddModal={handleOpenAddModal}
        onOpenGithubGuide={() => setIsGithubGuideOpen(true)}
        tripCount={trips.length}
      />

      {/* Main Content Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 md:p-6 flex flex-col">
        {/* Mobile Navigation Pills */}
        <div className="flex md:hidden items-center justify-between gap-2 mb-4 bg-[#142218] p-1 rounded-lg border border-[#273F2E]">
          <button
            onClick={() => setMobileTab('list')}
            className={`flex-1 py-1.5 rounded text-xs font-bold transition-all ${
              mobileTab === 'list'
                ? 'bg-[#E2A83B] text-[#16241B] shadow'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            Daftar Trip ({filteredTrips.length})
          </button>
          <button
            onClick={() => setMobileTab('detail')}
            disabled={!activeTrip}
            className={`flex-1 py-1.5 rounded text-xs font-bold transition-all ${
              mobileTab === 'detail'
                ? 'bg-[#E2A83B] text-[#16241B] shadow'
                : 'text-gray-300 hover:text-white disabled:opacity-40'
            }`}
          >
            Detail & Export
          </button>
        </div>

        {/* 2-Column Responsive Workspace */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 sm:gap-6 flex-1 items-start">
          {/* Left Column: Trip Directory & Filters */}
          <aside
            className={`md:col-span-5 lg:col-span-4 space-y-3.5 ${
              mobileTab === 'list' ? 'block' : 'hidden md:block'
            }`}
          >
            {/* Search & Status Filters Card */}
            <div className="bg-[#142218] border border-[#273F2E] rounded-xl p-3.5 space-y-3 shadow-md">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari gunung / jalur..."
                  className="w-full bg-[#0E1812] border border-[#2E4A35] rounded-lg pl-9 pr-3 py-2 text-xs sm:text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#E2A83B]"
                />
              </div>

              {/* Status Tabs */}
              <div className="flex items-center gap-1.5 pt-0.5">
                <span className="text-[11px] font-semibold text-gray-400 mr-1 flex items-center gap-1">
                  <Filter className="w-3 h-3 text-[#E2A83B]" /> Status:
                </span>
                {(['Semua', 'Buka', 'Tutup'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setFilterStatus(st)}
                    className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                      filterStatus === st
                        ? 'bg-[#E2A83B] text-[#16241B]'
                        : 'bg-[#1D2E22] text-gray-300 hover:bg-[#253D2D]'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Trip Cards List */}
            <div className="space-y-2.5 max-h-[calc(100vh-250px)] overflow-y-auto pr-1">
              {filteredTrips.length > 0 ? (
                filteredTrips.map((trip) => (
                  <TripCard
                    key={trip.id}
                    trip={trip}
                    isSelected={activeTrip?.id === trip.id}
                    onSelect={(t) => {
                      setSelectedTripId(t.id);
                      setMobileTab('detail');
                    }}
                    onEdit={handleOpenEditModal}
                    onDelete={handleDeleteTrip}
                    onOpenItinerary={handleOpenItineraryModal}
                  />
                ))
              ) : (
                <div className="bg-[#142218] border border-dashed border-[#2A4232] rounded-xl p-8 text-center space-y-3">
                  <Mountain className="w-10 h-10 text-gray-500 mx-auto" />
                  <p className="text-xs text-gray-400">Tidak ada trip yang sesuai pencarian.</p>
                  <button
                    onClick={handleOpenAddModal}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#E2A83B] text-[#16241B] text-xs font-bold hover:bg-[#EEBB55] transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Buat Trip Baru</span>
                  </button>
                </div>
              )}
            </div>
          </aside>

          {/* Right Column: Selected Trip Detail & Media Center */}
          <section
            className={`md:col-span-7 lg:col-span-8 ${
              mobileTab === 'detail' ? 'block' : 'hidden md:block'
            }`}
          >
            {/* Mobile Back to List Button */}
            <div className="md:hidden mb-3">
              <button
                onClick={() => setMobileTab('list')}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#E2A83B] hover:text-[#EEBB55] cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Daftar Trip</span>
              </button>
            </div>

            {activeTrip ? (
              <TripDetail
                trip={activeTrip}
                onEdit={handleOpenEditModal}
                onOpenItinerary={handleOpenItineraryModal}
                onShowToast={showToast}
              />
            ) : (
              <div className="bg-[#142218] border border-[#273F2E] rounded-xl p-12 text-center space-y-4">
                <Mountain className="w-14 h-14 text-emerald-600/40 mx-auto" />
                <h3 className="text-lg font-bold font-['Space_Grotesk'] text-white">
                  Pilih atau Tambahkan Trip
                </h3>
                <p className="text-xs text-gray-400 max-w-sm mx-auto">
                  Pilih salah satu jadwal open trip di sebelah kiri untuk melihat detail, menyalin caption Instagram, atau mengekspor poster pamflet & itinerary.
                </p>
                <button
                  onClick={handleOpenAddModal}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded bg-[#E2A83B] hover:bg-[#EEBB55] text-[#16241B] text-xs font-bold transition-all shadow cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Open Trip Pertama</span>
                </button>
              </div>
            )}
          </section>
        </div>
      </main>

      {/* Modals */}
      <TripModal
        isOpen={isTripModalOpen}
        onClose={() => setIsTripModalOpen(false)}
        onSave={handleSaveTrip}
        tripToEdit={tripToEdit}
      />

      <ItineraryModal
        isOpen={isItineraryModalOpen}
        onClose={() => setIsItineraryModalOpen(false)}
        trip={itineraryTrip}
        onUpdateTripItinerary={handleUpdateTripItinerary}
        onShowToast={showToast}
      />

      <GitHubGuideModal
        isOpen={isGithubGuideOpen}
        onClose={() => setIsGithubGuideOpen(false)}
        onShowToast={showToast}
      />

      {/* Notifications & Offline Status */}
      <OfflineIndicator />
      <Toast message={toastMessage} />
    </div>
  );
}
