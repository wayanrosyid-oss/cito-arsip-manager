import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Users,
  MapPin,
  CheckCircle,
  XCircle,
  AlertCircle,
  Copy,
  Check,
  Download,
  Image,
  FileText,
  Edit3,
  ExternalLink,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { Trip } from '../types';
import { formatDateRange, generateInstagramCaption } from '../utils/formatters';
import { exportTripPamphletPNG, exportItineraryPosterPNG } from '../utils/canvasExport';
import { exportTripPDF, exportTripTXT } from '../utils/pdfExport';

interface TripDetailProps {
  trip: Trip;
  onEdit: (trip: Trip) => void;
  onOpenItinerary: (trip: Trip) => void;
  onShowToast: (msg: string) => void;
}

export const TripDetail: React.FC<TripDetailProps> = ({
  trip,
  onEdit,
  onOpenItinerary,
  onShowToast,
}) => {
  const [copiedCaption, setCopiedCaption] = useState(false);
  const [isExporting, setIsExporting] = useState<string | null>(null);

  const captionText = generateInstagramCaption(trip);
  const isBuka = trip.status === 'Buka';
  const dateRange = formatDateRange(trip.tanggal_mulai, trip.tanggal_selesai) || 'Jadwal Terbuka';

  const handleCopyCaption = async () => {
    try {
      await navigator.clipboard.writeText(captionText);
      setCopiedCaption(true);
      onShowToast('Caption Instagram berhasil disalin ke clipboard!');
      setTimeout(() => setCopiedCaption(false), 2500);
    } catch {
      onShowToast('Gagal menyalin caption');
    }
  };

  const handleExportPamphlet = async (ratio: '4:5' | '9:16') => {
    setIsExporting(`pamflet-${ratio}`);
    onShowToast(`Membuat pamflet trip (${ratio})...`);
    try {
      await exportTripPamphletPNG(trip, ratio);
      onShowToast(`Pamflet Trip (${ratio}) berhasil diunduh!`);
    } catch (err) {
      console.error(err);
      onShowToast('Gagal membuat pamflet trip');
    } finally {
      setIsExporting(null);
    }
  };

  const handleExportItineraryPoster = async (ratio: '4:5' | '9:16') => {
    setIsExporting(`itin-${ratio}`);
    onShowToast(`Membuat poster itinerary (${ratio})...`);
    try {
      await exportItineraryPosterPNG(trip, ratio);
      onShowToast(`Poster Itinerary (${ratio}) berhasil diunduh!`);
    } catch (err) {
      console.error(err);
      onShowToast('Gagal membuat poster itinerary');
    } finally {
      setIsExporting(null);
    }
  };

  const handleExportPDF = () => {
    try {
      exportTripPDF(trip);
      onShowToast('Arsip PDF berhasil diunduh');
    } catch (err) {
      console.error(err);
      onShowToast('Gagal mengekspor PDF');
    }
  };

  const handleExportTXT = () => {
    try {
      exportTripTXT(trip);
      onShowToast('Arsip TXT berhasil diunduh');
    } catch (err) {
      console.error(err);
      onShowToast('Gagal mengekspor TXT');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner & Heading */}
      <div className="bg-[#15241B] border border-[#2B4232] rounded-xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold tracking-wide ${
                  isBuka
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${isBuka ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                Status: {trip.status}
              </span>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-[#E2A83B] bg-[#223528] px-2.5 py-1 rounded border border-[#314E3A]">
                <MapPin className="w-3.5 h-3.5" />
                {trip.jalur}
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold font-['Space_Grotesk'] text-white">
              🏔 {trip.nama_gunung.toUpperCase()} {trip.ketinggian_mdpl ? trip.ketinggian_mdpl.toUpperCase() : ''}
            </h2>
            <p className="text-sm font-semibold text-[#E2A83B] font-['Space_Grotesk']">
              📌 {trip.jalur.toUpperCase()}
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-center">
            <button
              onClick={() => onEdit(trip)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md bg-[#223829] hover:bg-[#2C4835] text-gray-200 border border-[#32523A] text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
            >
              <Edit3 className="w-4 h-4 text-[#E2A83B]" />
              <span>Edit Trip</span>
            </button>
          </div>
        </div>

        {/* Quick Meta Grid */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-[#263D2E]">
          <div className="bg-[#101913] p-3 rounded-lg border border-[#213527]">
            <span className="text-[11px] font-semibold text-gray-400 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#E2A83B]" /> Tanggal Pelaksanaan
            </span>
            <p className="text-sm sm:text-base font-bold text-white font-['Space_Grotesk'] mt-1">
              {dateRange}
            </p>
          </div>

          <div className="bg-[#101913] p-3 rounded-lg border border-[#213527]">
            <span className="text-[11px] font-semibold text-gray-400 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#E2A83B]" /> Durasi Pendakian
            </span>
            <p className="text-sm sm:text-base font-bold text-[#FCD34D] font-['Space_Grotesk'] mt-1">
              {trip.durasi}
            </p>
          </div>

          <div className="bg-[#101913] p-3 rounded-lg border border-[#213527]">
            <span className="text-[11px] font-semibold text-gray-400 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-[#E2A83B]" /> Target Kuota Peserta
            </span>
            <p className="text-sm sm:text-base font-bold text-white font-['Space_Grotesk'] mt-1">
              {trip.min_peserta || '-'} – {trip.max_peserta || '-'} Pax
            </p>
            <p className="text-[10px] text-[#FCD34D] italic mt-0.5">
              *(Jika peserta kurang, ada penyesuaian harga)
            </p>
          </div>
        </div>
      </div>

      {/* Export Action Bar (PNG 4:5 & 9:16, PDF, TXT) */}
      <div className="bg-[#18281E] border border-[#2B4232] rounded-xl p-4 sm:p-5 shadow">
        <h3 className="text-xs font-bold text-[#E2A83B] uppercase tracking-wider font-['Space_Grotesk'] mb-3 flex items-center gap-2">
          <Download className="w-4 h-4" />
          Pusat Export Media & Arsip Trip
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {/* Card Export Pamflet Feed & Story */}
          <div className="bg-[#111C14] border border-[#223527] rounded-lg p-3.5 space-y-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Image className="w-4 h-4 text-[#E2A83B]" />
              Export Pamflet Trip (Feed & Story)
            </span>
            <p className="text-[11px] text-gray-400 leading-snug">
              Gambar pamflet lengkap dengan harga mepo, fasilitas include/exclude & kontak.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => handleExportPamphlet('4:5')}
                disabled={isExporting !== null}
                className="flex-1 py-1.5 px-2 bg-[#223829] hover:bg-[#2C4835] text-[#E2A83B] border border-[#32523A] rounded text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>4:5 (Feed)</span>
              </button>
              <button
                onClick={() => handleExportPamphlet('9:16')}
                disabled={isExporting !== null}
                className="flex-1 py-1.5 px-2 bg-[#E2A83B] hover:bg-[#EEBB55] text-[#16241B] rounded text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer shadow"
              >
                <span>9:16 (Story)</span>
              </button>
            </div>
          </div>

          {/* Card Export Itinerary Poster */}
          <div className="bg-[#111C14] border border-[#223527] rounded-lg p-3.5 space-y-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-[#E2A83B]" />
              Export Rundown Itinerary (Poster)
            </span>
            <p className="text-[11px] text-gray-400 leading-snug">
              Poster khusus itinerary timeline per hari siap upload ke media sosial.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => handleExportItineraryPoster('4:5')}
                disabled={isExporting !== null}
                className="flex-1 py-1.5 px-2 bg-[#223829] hover:bg-[#2C4835] text-[#E2A83B] border border-[#32523A] rounded text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>4:5 (Feed)</span>
              </button>
              <button
                onClick={() => handleExportItineraryPoster('9:16')}
                disabled={isExporting !== null}
                className="flex-1 py-1.5 px-2 bg-[#E2A83B] hover:bg-[#EEBB55] text-[#16241B] rounded text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer shadow"
              >
                <span>9:16 (Story)</span>
              </button>
            </div>
          </div>

          {/* Card Export Dokumen PDF & TXT */}
          <div className="bg-[#111C14] border border-[#223527] rounded-lg p-3.5 space-y-2 sm:col-span-2 lg:col-span-1">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Download className="w-4 h-4 text-[#E2A83B]" />
              Dokumen Arsip Cetak
            </span>
            <p className="text-[11px] text-gray-400 leading-snug">
              Simpan seluruh data ke dokumen PDF resmi atau file teks (.TXT).
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleExportPDF}
                className="flex-1 py-1.5 px-2 bg-[#223829] hover:bg-[#2C4835] text-emerald-400 border border-[#32523A] rounded text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>Unduh PDF</span>
              </button>
              <button
                onClick={handleExportTXT}
                className="flex-1 py-1.5 px-2 bg-[#223829] hover:bg-[#2C4835] text-gray-200 border border-[#32523A] rounded text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>Unduh TXT</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Caption Instagram Generator Box */}
      <div className="bg-[#18281E] border border-[#2B4232] rounded-xl p-5 shadow">
        <div className="flex items-center justify-between gap-3 flex-wrap mb-3">
          <div>
            <h3 className="text-sm font-bold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#E2A83B]" />
              Caption Instagram Otomatis
            </h3>
            <p className="text-xs text-gray-300 mt-0.5">
              Include, Exclude, Itinerary, S&K, dan Catatan <strong>tidak diikutkan</strong> karena sudah masuk di pamflet postingan.
            </p>
          </div>
          <button
            onClick={handleCopyCaption}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded bg-[#E2A83B] hover:bg-[#EEBB55] text-[#16241B] text-xs font-bold transition-all cursor-pointer shadow active:scale-95"
          >
            {copiedCaption ? <Check className="w-4 h-4 text-green-900" /> : <Copy className="w-4 h-4" />}
            <span>{copiedCaption ? 'Caption Tersalin!' : 'Salin Caption'}</span>
          </button>
        </div>

        <div className="bg-[#101913] border border-[#223528] rounded-lg p-4 relative font-mono text-xs sm:text-sm text-emerald-300 leading-relaxed whitespace-pre-wrap select-all">
          {captionText}
        </div>
      </div>

      {/* Meeting Point & Pricing */}
      <div className="bg-[#15241B] border border-[#2B4232] rounded-xl p-5 shadow space-y-3">
        <h3 className="text-xs font-bold text-[#E2A83B] uppercase tracking-wider font-['Space_Grotesk']">
          Tarif per Meeting Point (MEPO)
        </h3>
        {trip.harga_mepo && trip.harga_mepo.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {trip.harga_mepo.map((m, idx) => (
              <div key={idx} className="bg-[#101913] border border-[#223527] rounded-lg p-3 flex items-center justify-between">
                <span className="text-xs font-semibold text-gray-200">{m.lokasi || 'Meeting Point'}</span>
                <span className="text-xs sm:text-sm font-bold text-[#FCD34D] font-['Space_Grotesk']">
                  {m.harga || '-'}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-gray-400">Belum ada data tarif meeting point.</p>
        )}
      </div>

      {/* Include & Exclude Facilities */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Include */}
        <div className="bg-[#15241B] border border-[#2B4232] rounded-xl p-5 shadow space-y-3">
          <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-['Space_Grotesk'] flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4" />
            Fasilitas Include
          </h3>
          <ul className="space-y-2 text-xs sm:text-sm text-gray-200">
            {(trip.include || []).map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-emerald-400 mt-0.5">✓</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Exclude */}
        <div className="bg-[#15241B] border border-[#2B4232] rounded-xl p-5 shadow space-y-3">
          <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider font-['Space_Grotesk'] flex items-center gap-1.5">
            <XCircle className="w-4 h-4" />
            Exclude (Tidak Termasuk)
          </h3>
          <ul className="space-y-2 text-xs sm:text-sm text-gray-200">
            {(trip.exclude || []).map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-rose-400 mt-0.5">✕</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
          {trip.extra_porter && (
            <div className="pt-2 border-t border-[#25392B] text-xs text-[#FCD34D] font-semibold">
              🎒 Extra Porter: {trip.extra_porter}
            </div>
          )}
        </div>
      </div>

      {/* Itinerary Preview & Action */}
      <div className="bg-[#15241B] border border-[#2B4232] rounded-xl p-5 shadow space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="text-xs font-bold text-[#E2A83B] uppercase tracking-wider font-['Space_Grotesk'] flex items-center gap-1.5">
            <Calendar className="w-4 h-4" />
            Rundown & Itinerary Kegiatan
          </h3>
          <button
            onClick={() => onOpenItinerary(trip)}
            className="text-xs font-bold text-[#E2A83B] hover:text-[#EEBB55] flex items-center gap-1 cursor-pointer"
          >
            <span>Buka Editor & Export Poster Itinerary</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-[#101913] border border-[#223528] rounded-lg p-4 font-mono text-xs text-gray-200 leading-relaxed whitespace-pre-wrap max-h-64 overflow-y-auto">
          {trip.itinerary || 'Belum ada rundown itinerary.'}
        </div>
      </div>

      {/* S&K & Catatan Penting */}
      <div className="bg-[#15241B] border border-[#2B4232] rounded-xl p-5 shadow space-y-4">
        {trip.sk_berlaku && trip.sk_berlaku.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-gray-300 uppercase font-['Space_Grotesk']">
              Syarat & Ketentuan (S&K):
            </h4>
            <ul className="space-y-1.5 text-xs text-gray-300">
              {trip.sk_berlaku.map((sk, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#E2A83B]">•</span>
                  <span>{sk}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {trip.catatan_penting && (
          <div className="p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/25 text-xs text-amber-200">
            <strong className="block text-[#E2A83B] mb-1 font-['Space_Grotesk']">Catatan Penting:</strong>
            {trip.catatan_penting}
          </div>
        )}
      </div>

      {/* Contact & Social Footer */}
      <div className="bg-[#101913] border border-[#223527] rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="text-gray-400">
          Booking & Informasi Resmi: <strong className="text-emerald-400">WA {trip.kontak_wa || '+6282230444428'}</strong> · <strong className="text-[#E2A83B]">IG {trip.kontak_ig || '@citoadventure'}</strong>
        </div>
        <div className="text-[11px] text-gray-500">
          Diperbarui: {new Date(trip.updated_at).toLocaleDateString('id-ID')}
        </div>
      </div>
    </div>
  );
};
