import React, { useState } from 'react';
import { X, Github, Copy, Check, Terminal, DownloadCloud } from 'lucide-react';
import { downloadProjectZip } from '../utils/projectZip';

interface GitHubGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string) => void;
}

export const GitHubGuideModal: React.FC<GitHubGuideModalProps> = ({
  isOpen,
  onClose,
  onShowToast,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const gitCommands = [
    {
      title: '1. Inisialisasi Git di Komputer / Terminal',
      cmd: `git init\ngit add .\ngit commit -m "feat: Cito Adventure PWA Trip Archive & Generator"`,
    },
    {
      title: '2. Hubungkan ke Repository GitHub Anda',
      cmd: `git branch -M main\ngit remote add origin https://github.com/USERNAME/NAMA-REPO-ANDA.git\ngit push -u origin main`,
    },
  ];

  const handleCopy = async (text: string, index: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      onShowToast('Perintah Git disalin ke clipboard');
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch {
      onShowToast('Gagal menyalin perintah');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#18261E] border border-[#2B4031] text-[#E8E6DF] w-full max-w-xl rounded-xl shadow-2xl overflow-hidden my-6">
        {/* Modal Header */}
        <div className="bg-[#121D17] px-6 py-4 border-b border-[#2B4031] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Github className="w-5 h-5 text-[#E2A83B]" />
            <h3 className="font-bold text-base sm:text-lg font-['Space_Grotesk'] text-white">
              Panduan Repository GitHub & Export ZIP
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-sm">
          {/* Quick ZIP Download Option */}
          <div className="bg-[#203428] border border-[#3A5C47] rounded-lg p-4 flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h4 className="font-bold text-white flex items-center gap-2">
                <DownloadCloud className="w-4 h-4 text-[#E2A83B]" />
                Gabungkan Semua File Jadi ZIP
              </h4>
              <p className="text-xs text-gray-300 mt-1">
                Unduh seluruh source code proyek ini langsung ke komputermu dalam 1 file ZIP lengkap siap pakai.
              </p>
            </div>
            <button
              onClick={() => {
                downloadProjectZip();
                onShowToast('Mulai mengunduh file ZIP proyek...');
              }}
              className="px-3.5 py-2 bg-[#E2A83B] hover:bg-[#EEBB55] text-[#16241B] font-bold text-xs rounded transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <DownloadCloud className="w-4 h-4" />
              <span>Download ZIP</span>
            </button>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#E2A83B]" />
              Langkah Push ke Repository GitHub Anda
            </h4>
            <p className="text-xs text-gray-300">
              Buat repository baru di <a href="https://github.com/new" target="_blank" rel="noreferrer" className="text-[#E2A83B] underline font-semibold">github.com/new</a>, lalu jalankan perintah berikut di folder proyek:
            </p>

            {gitCommands.map((item, idx) => (
              <div key={idx} className="bg-[#101813] border border-[#233529] rounded-lg p-3 relative">
                <div className="flex items-center justify-between text-xs text-[#E2A83B] font-semibold mb-2">
                  <span>{item.title}</span>
                  <button
                    onClick={() => handleCopy(item.cmd, idx)}
                    className="flex items-center gap-1 text-gray-300 hover:text-white px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    {copiedIndex === idx ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-green-400" />
                        <span className="text-green-400 text-[11px]">Tersalin</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="text-[11px]">Salin</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="font-mono text-xs text-emerald-300/90 whitespace-pre-wrap leading-relaxed overflow-x-auto">
                  {item.cmd}
                </pre>
              </div>
            ))}
          </div>

          <div className="bg-[#142018] border border-[#273B2E] rounded-lg p-3 text-xs text-gray-300 space-y-1">
            <p className="font-semibold text-[#E2A83B]">💡 Ikon PWA Resmi Telah Dikonfigurasi:</p>
            <p>Logo Cito Adventure yang Anda unggah sudah otomatis dijadikan ikon aplikasi PWA (<code className="text-amber-300">pwa-192x192.png</code>, <code className="text-amber-300">pwa-512x512.png</code>, <code className="text-amber-300">apple-touch-icon.png</code>, dan favicon).</p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-[#121D17] px-6 py-3 border-t border-[#2B4031] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded text-xs font-semibold bg-[#223528] hover:bg-[#2A4232] text-gray-200 transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
