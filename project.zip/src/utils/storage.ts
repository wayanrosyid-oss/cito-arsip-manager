import { Trip } from '../types';
import { generateDefaultItinerary } from './formatters';

const STORAGE_KEY = 'cito_adventure_trips_v2';

export const INITIAL_TRIPS: Trip[] = [
  {
    id: 'sindoro-kledung',
    nama_gunung: 'Gunung Sindoro',
    ketinggian_mdpl: '3.153 MDPL',
    jalur: 'Via Kledung',
    status: 'Buka',
    tanggal_mulai: '2026-09-10',
    tanggal_selesai: '2026-09-11',
    durasi: '2 Hari 1 Malam',
    min_peserta: '15',
    max_peserta: '30',
    harga_mepo: [
      { lokasi: 'Basecamp Kledung', harga: 'IDR 600.000' },
      { lokasi: 'Stasiun Purwokerto', harga: 'IDR 750.000' },
      { lokasi: 'Madiun (Meeting Point)', harga: 'IDR 700.000' },
      { lokasi: 'Jakarta (Cawang/UKI)', harga: 'IDR 950.000' }
    ],
    include: [
      'Transportasi PP AC sesuai meeting point',
      'Simaksi & Asuransi Pendakian Resmi',
      'Tenda kapasitas 4 (diisi 3 orang agar nyaman)',
      'Matras busa per peserta',
      'Makan 3x selama masa pendakian (menu bergizi)',
      'Air mineral & welcome drink hangat (teh/kopi)',
      'Peralatan masak & makan kelompok',
      'Porter tim (membawa tenda & logistik bersama)',
      'Tour Leader & Guide Berpengalaman Cito Adventure',
      'Dokumentasi foto perjalanan & P3K standar'
    ],
    exclude: [
      'Perlengkapan pribadi (carrier, sleeping bag, jaket)',
      'Ojek basecamp ke pos 1 (opsional)',
      'Obat-obatan pribadi khusus',
      'Camilan & logistik pribadi di luar program',
      'Tips sukarela crew / guide / porter'
    ],
    extra_porter: 'Tersedia jika diperlukan (Rp 300.000 / hari)',
    sk_berlaku: [
      'Terbuka untuk umum (solo hiker dipersilakan join)',
      'DP minimal 50% untuk pengamanan kuota seat',
      'Pelunasan maksimal H-3 sebelum keberangkatan',
      'Pembatalan oleh peserta DP hangus namun bisa digantikan orang lain',
      'Wajib membawa surat keterangan sehat dari dokter'
    ],
    catatan_penting: 'Sebelum mendaki, sangat disarankan untuk latihan fisik ringan (jogging) minimal seminggu sebelum keberangkatan. Suhu di puncak Sindoro bisa mencapai 5-8 derajat celcius, pastikan jaket windproof dan sleeping bag dibawa.',
    itinerary: generateDefaultItinerary('Gunung Sindoro', 'Via Kledung', '2026-09-10', '2026-09-11'),
    kontak_wa: '+6282230444428',
    kontak_ig: 'Cito Adventure Madiun',
    created_at: Date.now() - 100000,
    updated_at: Date.now() - 100000,
  },
  {
    id: 'sumbing-butuh',
    nama_gunung: 'Gunung Sumbing',
    ketinggian_mdpl: '3.371 MDPL',
    jalur: 'Via Butuh (Nepal Van Java)',
    status: 'Buka',
    tanggal_mulai: '2026-09-17',
    tanggal_selesai: '2026-09-19',
    durasi: '3 Hari 2 Malam',
    min_peserta: '12',
    max_peserta: '25',
    harga_mepo: [
      { lokasi: 'Basecamp Butuh', harga: 'IDR 650.000' },
      { lokasi: 'Terminal Magelang', harga: 'IDR 750.000' },
      { lokasi: 'Stasiun Tugu Solo / Jogja', harga: 'IDR 850.000' },
      { lokasi: 'Madiun', harga: 'IDR 800.000' }
    ],
    include: [
      'Transportasi PP lokal sesuai mepo',
      'Tiket Simaksi resmi Taman Nasional',
      'Tenda & Matras camping',
      'Makan 5x selama pendakian di gunung',
      'Peralatan masak & gas',
      'Porter tenda & logistik bersama',
      'Guide ramah & berlisensi Cito Adventure',
      'P3K darurat & dokumentasi'
    ],
    exclude: [
      'Ojek Nepal van Java ke batas ladang (opsional)',
      'Sleeping bag & pakaian hangat pribadi',
      'Pengeluaran pribadi'
    ],
    extra_porter: 'Rp 350.000 / hari jika butuh porter beban pribadi',
    sk_berlaku: [
      'Peserta dinyatakan fix setelah membayar DP 50%',
      'Sehat jasmani dan rohani',
      'Patuhi kode etik pencinta alam dan arahan guide'
    ],
    catatan_penting: 'Jalur Butuh terkenal dengan keindahan pedesaan Nepal Van Java. Harap siapkan jas hujan dan pakaian ganti kedap air dalam plastik.',
    itinerary: generateDefaultItinerary('Gunung Sumbing', 'Via Butuh', '2026-09-17', '2026-09-19'),
    kontak_wa: '+6282230444428',
    kontak_ig: 'Cito Adventure Madiun',
    created_at: Date.now() - 200000,
    updated_at: Date.now() - 200000,
  },
  {
    id: 'merbabu-suwanting',
    nama_gunung: 'Gunung Merbabu',
    ketinggian_mdpl: '3.145 MDPL',
    jalur: 'Via Suwanting',
    status: 'Tutup',
    tanggal_mulai: '2026-08-20',
    tanggal_selesai: '2026-08-21',
    durasi: '2 Hari 1 Malam',
    min_peserta: '15',
    max_peserta: '25',
    harga_mepo: [
      { lokasi: 'Basecamp Suwanting', harga: 'IDR 550.000' },
      { lokasi: 'Stasiun Solo Balapan', harga: 'IDR 700.000' },
      { lokasi: 'Terminal Madiun', harga: 'IDR 650.000' }
    ],
    include: [
      'Simaksi & booking online Merbabu',
      'Transportasi PP mepo',
      'Tenda dome + matras',
      'Makan 3x',
      'Guide & Porter kelompok',
      'Dokumentasi'
    ],
    exclude: [
      'Sleeping bag & carrier',
      'Logistik snack pribadi'
    ],
    extra_porter: 'Rp 300.000 / hari',
    sk_berlaku: [
      'Pendaftaran ditutup H-7 atau jika kuota simaksi habis',
      'Wajib membawa identitas KTP/SIM asli'
    ],
    catatan_penting: 'Jalur Suwanting memiliki trek menanjak yang konstan dengan pemandangan sabana yang luar biasa.',
    itinerary: generateDefaultItinerary('Gunung Merbabu', 'Via Suwanting', '2026-08-20', '2026-08-21'),
    kontak_wa: '+6282230444428',
    kontak_ig: 'Cito Adventure Madiun',
    created_at: Date.now() - 300000,
    updated_at: Date.now() - 300000,
  }
];

export function getStoredTrips(): Trip[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_TRIPS));
      return INITIAL_TRIPS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_TRIPS;
  } catch {
    return INITIAL_TRIPS;
  }
}

export function saveStoredTrips(trips: Trip[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trips));
  } catch (err) {
    console.error('Failed to save to localStorage', err);
  }
}
